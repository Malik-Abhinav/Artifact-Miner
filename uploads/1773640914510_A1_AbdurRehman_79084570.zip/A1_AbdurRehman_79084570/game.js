function main() {
  var canvasElem = document.getElementById("disk");
  if (!canvasElem) {
    console.log("Failed to retrieve canvas element");
    return;
  }

  var glCtx = canvasElem.getContext("webgl");
  var shaderProgram = initShaders(glCtx, "VSHADER_SOURCE", "FSHADER_SOURCE");
  glCtx.useProgram(shaderProgram);

  var segmentCount = 100;
  var diskRadius = 0.7;

  var diskVerts = [0, 0];
  for (var i = 0; i <= segmentCount; i++) {
    var theta = (i * 2 * Math.PI) / segmentCount;
    diskVerts.push(Math.cos(theta) * diskRadius, Math.sin(theta) * diskRadius);
  }

  var diskBuffer = glCtx.createBuffer();
  glCtx.bindBuffer(glCtx.ARRAY_BUFFER, diskBuffer);
  glCtx.bufferData(
    glCtx.ARRAY_BUFFER,
    new Float32Array(diskVerts),
    glCtx.STATIC_DRAW,
  );

  var posAttrib = glCtx.getAttribLocation(shaderProgram, "disk_position");
  glCtx.vertexAttribPointer(posAttrib, 2, glCtx.FLOAT, false, 0, 0);
  glCtx.enableVertexAttribArray(posAttrib);

  var colorUniform = glCtx.getUniformLocation(shaderProgram, "cColor");
  var diskColor = [1.0, 1.0, 1.0, 1.0]; // white disk

  glCtx.clearColor(0.0, 0.0, 0.0, 1.0);
  glCtx.clear(glCtx.COLOR_BUFFER_BIT);
  glCtx.uniform4fv(colorUniform, diskColor);
  glCtx.drawArrays(glCtx.TRIANGLE_FAN, 0, diskVerts.length / 2);

  var maxBacteria = 10;
  var initialGrowth = diskRadius / 5;
  var spawnAngle = Math.random() * 2 * Math.PI;
  var bacteriaList = [];
  var spawnCount = 0;

  renderFrame();

  function renderFrame() {
    glCtx.clear(glCtx.COLOR_BUFFER_BIT);

    glCtx.bindBuffer(glCtx.ARRAY_BUFFER, diskBuffer);
    glCtx.vertexAttribPointer(posAttrib, 2, glCtx.FLOAT, false, 0, 0);
    glCtx.enableVertexAttribArray(posAttrib);

    glCtx.uniform4fv(colorUniform, diskColor);
    glCtx.drawArrays(glCtx.TRIANGLE_FAN, 0, diskVerts.length / 2);

    for (var b = 0; b < bacteriaList.length; b++) {
      var bug = bacteriaList[b];
      bug.size += bug.speed;

      var bugVerts = [bug.x, bug.y];
      for (var i = 0; i <= segmentCount; i++) {
        var a = (i * 2 * Math.PI) / segmentCount;
        bugVerts.push(
          bug.x + Math.cos(a) * bug.size,
          bug.y + Math.sin(a) * bug.size,
        );
      }

      var bugBuffer = glCtx.createBuffer();
      glCtx.bindBuffer(glCtx.ARRAY_BUFFER, bugBuffer);
      glCtx.bufferData(
        glCtx.ARRAY_BUFFER,
        new Float32Array(bugVerts),
        glCtx.STATIC_DRAW,
      );

      glCtx.vertexAttribPointer(posAttrib, 2, glCtx.FLOAT, false, 0, 0);
      glCtx.enableVertexAttribArray(posAttrib);

      glCtx.uniform4fv(colorUniform, bug.color);
      glCtx.drawArrays(glCtx.TRIANGLE_FAN, 0, bugVerts.length / 2);
    }

    if (spawnCount < maxBacteria) {
      var delta = Math.random() * 4;
      spawnAngle += delta > 0 && delta < 2 ? delta : -delta;

      var bx = Math.cos(spawnAngle) * diskRadius;
      var by = Math.sin(spawnAngle) * diskRadius;

      bacteriaList.push({
        x: bx,
        y: by,
        color: [Math.random(), Math.random(), Math.random(), 1.0],
        size: initialGrowth,
        speed: Math.random() * 0.02 + 0.01,
      });
    }

    spawnCount++;
    setTimeout(renderFrame, 1000);
  }
}
