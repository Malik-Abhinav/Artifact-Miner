function main(){ 
    var canvas = document.getElementById('disk');

    if(!canvas) {
        console.log('Failed to retrieve canvas element');
        return;
    }

    var gl = canvas.getContext('webgl');
    var program= initShaders(gl, 'VSHADER_SOURCE', 'FSHADER_SOURCE');
    gl.useProgram(program);

    var vertices = [0, 0];
    var seg= 100;
    var radius=0.7;

    for(var i=0; i<=seg; i++) {
        var angle = i * 2 * Math.PI / seg;
        var x = Math.cos(angle) * radius;
        var y = Math.sin(angle) * radius;
        vertices.push(x, y);
    }

    var vertexBuffer= gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    var disk_position= gl.getAttribLocation(program, 'disk_position');
    gl.vertexAttribPointer(disk_position, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(disk_position);

    var cColor=gl.getUniformLocation(program, "cColor");
    var colorSet=[1.0, 1.0, 1.0, 1.0]; //white main disk

    gl.clearColor(0.0, 0.0, 0.0, 1.0); //black
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform4fv(cColor, colorSet);
    gl.drawArrays(gl.TRIANGLE_FAN, 0, vertices.length / 2);

    var numCircles=10;
    var newRadius= radius/5;
    //this is calculating the random angle for spawning bacteria on the circumference
    var angle = Math.random() * 2 * Math.PI;
    var j=0;
    var circles=[];

    drawNext();

    function drawNext(){
        var vertexBuffer= gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
        var disk_position= gl.getAttribLocation(program, 'disk_position');
        gl.vertexAttribPointer(disk_position, 2, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(disk_position);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.uniform4fv(cColor, colorSet);
        gl.drawArrays(gl.TRIANGLE_FAN, 0, vertices.length / 2);

        // Draw all existing bacteria (they just keep growing)
        for(var k=0; k<circles.length; k++){
            var current=circles[k];
            
            // Bacteria continues to grow
            current.growth += current.growthRate;
            var newVertices=[current.w, current.z];

            //bacteria should grow uniformly in a circle from its starting point
            for(var i=0; i<=seg; i++) {
                var smallAngle = i * 2 * Math.PI / seg;
                var x = current.w + Math.cos(smallAngle) * current.growth;
                var y = current.z + Math.sin(smallAngle) * current.growth;
                newVertices.push(x, y);
            }

            var smallCircleBuffer = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, smallCircleBuffer);
            gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(newVertices), gl.STATIC_DRAW);
            var smallCircle_position= gl.getAttribLocation(program, 'disk_position');
            gl.vertexAttribPointer(smallCircle_position, 2, gl.FLOAT, false, 0, 0);
            gl.enableVertexAttribArray(smallCircle_position);

            var newC = current.newColor;
            gl.uniform4fv(cColor, newC);
            gl.drawArrays(gl.TRIANGLE_FAN, 0, newVertices.length / 2);
        }

        // Spawn new bacteria until we reach numCircles
        if(j<numCircles) {
            var random= Math.random()*4;
            if(random>0 && random<2) {
                angle=angle+random;
            }
            else {
                angle=angle-random;
            }

            //make sure that the bacteria is on the circumference
            var w = Math.cos(angle) * radius;
            var z = Math.sin(angle) * radius;
            //choose random color
            var newColor = [Math.random(), Math.random(), Math.random(), 1.0];
            //growth rate of the bacteria (will be random)
            var growthRate = Math.random() * 0.02 + 0.01;
            
            circles.push({w: w, z: z, newColor: newColor, growth: newRadius, growthRate: growthRate});
        }
        
        j++;
        setTimeout(drawNext, 1000);
    }
}